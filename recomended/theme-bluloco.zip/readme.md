## Acode Bluloco Theme  
Inspired by the Bluloco Dark Theme 


[Available on Visual Studio Marketplace](https://marketplace.visualstudio.com/items?itemName=uloco.theme-bluloco-dark)  

### **Description**  
An elegant and sophisticated dark color scheme for **Visual Studio Code**.  

This theme stands out through the comprehensive use of syntax scopes and color consistency, prioritizing aesthetics, contrast, and readability. Originally based on the beautiful **One Dark Theme**, it has been enhanced with Bluloco's intuitive and meaningful color palette.  

---
<details>
    <summary>
      <h3 style="display:inline">Update v1.0.1</h3>
    </summary>
  
  
  - *Bug Fixed*
  
   

</details>

## Installation

1. **Install the Plugin in Acode**  
   Open the Acode App and navigate to:  
   `Acode > Settings > Plugins > Bluloco`, then install the plugin.

1. Open Acode Editor.
2. Go to the `settings > Theme > Editor`.
3. Select "Bluloco Theme"
4. Apply the theme.

**Syntax Palette**


| **Scope**     | **Color** | **HEX**    |
|-------------------------|-----------|------------|
| *Background*          | ![#282c34](https://via.placeholder.com/15/282c34/282c34)  | `#282c34` |
| *Foreground*          | ![#abb2bf](https://via.placeholder.com/15/abb2bf/abb2bf)  | `#abb2bf` |
| *Comment*             | ![#636d83](https://via.placeholder.com/15/636d83/636d83) | `#636d83` |
| *Keyword*             | ![#10b1fe](https://via.placeholder.com/15/10b1fe/10b1fe) | `#10b1fe` |
| *Function/Method*     | ![#3fc56b](https://via.placeholder.com/15/3fc56b/3fc56b) | `#3fc56b` |
| *Property*            | ![#ce9887](https://via.placeholder.com/15/ce9887/ce9887) | `#ce9887` |
| *String*              | ![#f9c859](https://via.placeholder.com/15/f9c859/f9c859) | `#f9c859` |
| *Number*              | ![#ff78f8](https://via.placeholder.com/15/ff78f8/ff78f8) | `#ff78f8` |
| *Constant*            | ![#9f7efe](https://via.placeholder.com/15/9f7efe/9f7efe) | `#9f7efe` |
| *Markup Tag*          | ![#3691ff](https://via.placeholder.com/15/3691ff/3691ff) | `#3691ff` |
| *Markup Attribute*    | ![#ff936a](https://via.placeholder.com/15/ff936a/ff936a) | `#ff936a` |
| *Class/Type/Interface*  | ![#ff6480](https://via.placeholder.com/15/ff6480/ff6480) | `#ff6480` |
| *Operator/Punctuation*  | ![#7a82da](https://via.placeholder.com/15/7a82da/7a82da) | `#7a82da` |

**HTML**

[![HTML](https://i.ibb.co/5GBGMG2/html.jpg)](https://ibb.co/5GBGMG2)

**GO**

[![GO](https://i.ibb.co/xH5nhSY/go.jpg)](https://ibb.co/xH5nhSY)


**JS**

[![JS](https://i.ibb.co/VHX92Cq/js.jpg)](https://ibb.co/VHX92Cq)

**Python**

[![Python](https://i.ibb.co/tzNnHBs/py.jpg)](https://ibb.co/tzNnHBs)

**PHP**

[![PHP](https://i.ibb.co/qW5Swrd/php.jpg)](https://ibb.co/qW5Swrd)

**TS**

[![TS](https://i.ibb.co/tz6NX9D/ts.jpg)](https://ibb.co/tz6NX9D)

## Acknowledgement

This extension was written by cloning [vscode-theme-extension](https://github.com/legendSabbir/acode-editorTheme-template)